# elevatoroffline
We attached 3 links of an effective solution to the elevator 
problem. 

1) https://www.youtube.com/watch?v=JXqVvmBOyyQ&t=206s
2) https://www.youtube.com/watch?v=xOayymoIl8U
3) https://www.youtube.com/watch?v=TDww3MjL-0A&t=555s

Offline Algorithm
We will divide the execution of the operations into 3 parts.
Part1: ( quantity of calls at that moment to different floors to different 
destinations) 
Because we know in advance the call list then we start the resting places 
of the lifts scattered appropriately and efficiently that the call will be 
done quickly so if we have a lot of calls at that moment because the lifts 
are scattered throughout the building so any elevator close to the call 
floor will go carry out the command at the end all the elevators return to 
. the rest floor
Part2 : (different times to the same floor and to the same destinations)
All the elevators work like part 1.
Part3 : (when there many calls in different floors and to the same 
destinations)
If our direction is down and the elevator is on the middle floor between 
the two calls it will first make the calls from above and when it goes 
down answers the call from below and then everyone on the middle 
floor in the same direction answers the call
And the opposite direction works the same
